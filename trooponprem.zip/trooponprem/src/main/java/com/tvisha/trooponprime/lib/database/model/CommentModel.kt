package com.tvisha.trooponprime.lib.database.model

data class CommentModel(
    var comment: String? = null,
    var comment_id:String? = null,
    var created_at: String? = null,
)

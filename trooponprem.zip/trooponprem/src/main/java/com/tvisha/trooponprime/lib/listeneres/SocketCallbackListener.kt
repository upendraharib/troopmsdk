package com.tvisha.trooponprime.lib.listeneres

internal interface SocketCallbackListener {
    fun syncData()
}
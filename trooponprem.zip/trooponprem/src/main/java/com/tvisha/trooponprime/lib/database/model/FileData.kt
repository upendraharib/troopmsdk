package com.tvisha.troopmessenger.FileDeck.Model

data class FileData(
    var file_id:Int=0,
    var folder_id:Int = 0,
    var file_path:String?=null,
    var filename:String?=null
)

package com.tvisha.trooponprime.lib.database.model

data class UnSentMessage(
    var message_id:Long=0,
    var plat_form:Int = 0,
)
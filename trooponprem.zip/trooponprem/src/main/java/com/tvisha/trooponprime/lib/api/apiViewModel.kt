package com.tvisha.trooponprime.lib.api

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.jakewharton.retrofit2.adapter.kotlin.coroutines.CoroutineCallAdapterFactory
import com.tvisha.trooponprime.lib.TroopClient
import com.tvisha.trooponprime.lib.utils.ConstantValues
import com.tvisha.trooponprime.lib.viewmodel.ApiRepository
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import org.koin.dsl.module
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.converter.scalars.ScalarsConverterFactory
import java.util.concurrent.TimeUnit

val apiViewModel = module {
    factory {
        //val logging = HttpLoggingInterceptor()
        //logging.level = HttpLoggingInterceptor.Level.BODY
        OkHttpClient.Builder()
            .connectTimeout(1, TimeUnit.MINUTES)
            .writeTimeout(1, TimeUnit.MINUTES)
            .readTimeout(1, TimeUnit.MINUTES)
            .addInterceptor { chain ->
                val original = chain.request()
                val newRequest  = original.newBuilder()
                    .header("Accept-Language", "en")
                    .header("Content-Type", "application/json")
                    .method(original.method, original.body)
                    .build()
                chain.proceed(newRequest)
            }
            //.addInterceptor(logging)
//            .addInterceptor(
//                    HttpLoggingInterceptor(HttpLoggingInterceptor.Logger {
//                        CommonUtils.appDebugLog("API", it)
//                    })
//                            .setLevel(if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.HEADERS else HttpLoggingInterceptor.Level.NONE)
//                            .setLevel(if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BODY else HttpLoggingInterceptor.Level.NONE)
//            )
//            .authenticator(get())
            .build()
    }
    factory<Gson> {
        GsonBuilder()
            .setLenient()
            .create()
    }
    single {
        Retrofit.Builder()
            .client(get())
            .baseUrl(ConstantValues.API_BASE_URL+"/")
            .addConverterFactory(ScalarsConverterFactory.create())
            .addCallAdapterFactory(CoroutineCallAdapterFactory())
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    factory { get<Retrofit>().create(BaseAPIService::class.java) }

    single { ApiRepository(get()) }

}
package com.tvisha.trooponprime.lib.database.model

data class UserModel(
    var user_id:Long = 0,
    var name :String = "",
    var profile_pic:String = ""
)

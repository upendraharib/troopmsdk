package com.tvisha.trooponprime.lib.utils

import com.tvisha.trooponprime.lib.api.apiViewModel
import com.tvisha.trooponprime.lib.viewmodel.ApiViewModel
import com.tvisha.trooponprime.lib.viewmodel.DataBaseViewModel
import com.tvisha.trooponprime.lib.viewmodel.viewModeModule

val appComponent = listOf(apiViewModel,viewModeModule)
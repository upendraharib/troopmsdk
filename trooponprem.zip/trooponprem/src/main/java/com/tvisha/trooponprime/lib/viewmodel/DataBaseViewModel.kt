package com.tvisha.trooponprime.lib.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.*
import com.tvisha.trooponprime.lib.clientModels.ConversationModel
import com.tvisha.trooponprime.lib.clientModels.RecentMessageList
import com.tvisha.trooponprime.lib.database.model.RecentLastMessage
import com.tvisha.trooponprime.lib.database.model.RecentList
import dagger.Lazy
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import javax.inject.Inject

class DataBaseViewModel @Inject constructor(
    private val repository : Lazy<DataBaseRepository>
): ViewModel(){
    init {
        repository.get()
    }
    /*private fun fetchRecentList(): LiveData<List<RecentList>> {
        return repository.get().fetchWorkspaceRecentListData()
    }
    private fun fetchConversation(): Flow<PagingData<Messenger>> {
        return repository.get().fetchWorkspaceConversation()
    }
    private fun fetchFileDeckList() : LiveData<List<RecentList>>{
        return repository.get().fetchFileDeckList("","","",false)
    }*/

    /*fun fetchRecentMessages():LiveData<List<RecentMessageList>>{
        return repository.get().fetchRecentMessages()
    }*/
    /*fun fetchConversation(userId:String,entityId:String,entity:Int):Flow<PagingData<ConversationModel>>{
        return Pager(
            config = PagingConfig(
                pageSize = 1000,
                prefetchDistance = 50,
                enablePlaceholders = false,
                initialLoadSize = 1000,
                maxSize = 200000
            )
        ) {
            repository.get().fetchConversation(userId,entityId,entity)
        }.flow.map { pagingData ->
            pagingData.map { cheese -> cheese }
        }.cachedIn(dataBaseViewModel!!.viewModelScope).flowOn(Dispatchers.IO)
    }*/
}
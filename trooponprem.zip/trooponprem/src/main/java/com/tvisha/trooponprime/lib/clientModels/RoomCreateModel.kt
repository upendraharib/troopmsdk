package com.tvisha.trooponprime.lib.clientModels

data class RoomCreateModel(
    var room_name:String="",
    var room_description:String="",
    var room_avatar:String="",
    var conversation_reference_id:String="",
)
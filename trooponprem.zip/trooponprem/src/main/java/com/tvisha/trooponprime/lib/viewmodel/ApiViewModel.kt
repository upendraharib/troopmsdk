package com.tvisha.trooponprime.lib.viewmodel

import android.util.Log
import androidx.compose.ui.unit.Constraints
import androidx.lifecycle.ViewModel
import com.iq.atoms.data.base.ResponseResult
import com.tvisha.trooponprime.lib.TroopClient
import com.tvisha.trooponprime.lib.TroopMessengerClient.Companion.APPLICATION_LOGIN_U_ID
import com.tvisha.trooponprime.lib.TroopMessengerClient.Companion.APPLICATION_TM_LOGIN_USER_ID
import com.tvisha.trooponprime.lib.TroopMessengerClient.Companion.APP_AUTHORIZATION_TOKEN
import com.tvisha.trooponprime.lib.TroopMessengerClient.Companion.APP_LOGIN_USER_MOBILE_NUMBER
import com.tvisha.trooponprime.lib.TroopMessengerClient.Companion.APP_LOGIN_USER_NAME
import com.tvisha.trooponprime.lib.TroopMessengerClient.Companion.dataBase
import com.tvisha.trooponprime.lib.TroopMessengerClient.Companion.sharedPreferences
import com.tvisha.trooponprime.lib.database.Contact
import com.tvisha.trooponprime.lib.socket.TroopSocketClient
import com.tvisha.trooponprime.lib.utils.ConstantValues
import com.tvisha.trooponprime.lib.utils.Helper
import com.tvisha.trooponprime.lib.utils.SharePreferenceConstants
import dagger.Lazy
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import retrofit2.Response
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import javax.inject.Inject
import kotlin.coroutines.CoroutineContext


class ApiViewModel @Inject constructor (private val apiBaseRepository: ApiRepository):ViewModel() {

    private val viewModelJob = Job()
    private val ioScope = CoroutineScope(Dispatchers.IO + viewModelJob)
    val uiScope = CoroutineScope(Dispatchers.Main)
    suspend fun callRegister(uid:String,name:String,mobileNumber:String,countryCode:String){
        ioScope.launch {
            var responseResult = apiBaseRepository.register(ConstantValues.TOKEN,uid,name,mobileNumber,countryCode)
            uiScope.launch {
                if (responseResult is ResponseResult.Success){
                    var jsonObject = Helper.stringToJsonObject(responseResult.data)
                    if (jsonObject!=null && jsonObject.optBoolean("success")) {
                        var edit = sharedPreferences!!.edit()
                        edit.putBoolean(SharePreferenceConstants.TM_USER_LOGIN_STATUS, true).apply()
                        edit.putString(SharePreferenceConstants.TM_LOGIN_USER_ID,jsonObject.optString("tm_user_id")).apply()
                        edit.putString(SharePreferenceConstants.TM_LOGIN_USER_NAME,name)
                        edit.putString(SharePreferenceConstants.TM_LOGIN_USER_MOBILE,mobileNumber)
                        edit.putString(SharePreferenceConstants.TM_LOGIN_USER_COUNTRY_CODE,countryCode)
                        edit.putString(SharePreferenceConstants.TM_LOGIN_USER_UID,uid)
                        APP_LOGIN_USER_MOBILE_NUMBER = mobileNumber
                        APPLICATION_LOGIN_U_ID = uid
                        APPLICATION_TM_LOGIN_USER_ID = jsonObject.optString("tm_user_id")
                        APP_LOGIN_USER_NAME = name
                        APP_AUTHORIZATION_TOKEN = jsonObject.optString("authorization_token")
                        edit.apply()

                    }
                }
            }
        }
    }
    suspend fun syncContacts(userId:String,at:String,contacts:String){
        ioScope.launch {
            var responseResult = apiBaseRepository.syncContacts(ConstantValues.TOKEN,userId,at,contacts,ConstantValues.deviceId,ConstantValues.PLATFORM_ANDROID)
            uiScope.launch {
                if (responseResult is  ResponseResult.Success){
                    var response = Helper.stringToJsonObject(responseResult.data)
                    if (response!=null && response.optBoolean("success")) {
                        if (response.has("contacts") && response.optJSONArray("contacts")!!.length()>0){
                            val contactList : ArrayList<Contact> = ArrayList()
                            val updatedAtTime = ConstantValues.fetchCurrentTimeInUTC()
                            var contactLength = response.optJSONArray("contacts")!!.length()
                            for (i in 0 until contactLength) {
                                var contactObject = response.optJSONArray("contacts")!!.optJSONObject(i)
                                var contact = Contact()
                                contact.id = contactObject.optLong("id")
                                contact.name = contactObject.optString("name")
                                contact.uid = contactObject.optString("uid")
                                contact.created_at= updatedAtTime!!
                                contact.updated_at = updatedAtTime!!
                                contactList.add(contact)
                            }
                            dataBase!!.contactDAO.insertBulkContacts(contactList)
                        }
                        if (response.has("deleted_contact_names") && response.optJSONArray("deleted_contact_names")!!.length()>0){
                            for (i in 0 until response.optJSONArray("deleted_contact_names")!!.length()){
                                dataBase!!.userDAO.updateUserName(response.optJSONArray("deleted_contact_names")!!.optJSONObject(i).optString("user_id"),response.optJSONArray("deleted_contact_names")!!.optJSONObject(i).optString("name"))
                            }
                        }
                    }
                }
            }
        }
    }
    suspend fun fetchAllMessages(){
        ioScope.launch {
            var responseResult = apiBaseRepository.fetchAllMessages()
            uiScope.launch {
                if (responseResult is  ResponseResult.Success) {
                    var response = Helper.stringToJsonObject(responseResult.data)
                    if (response != null && response.optBoolean("success")) {
                        if (response.has("messages") && response.optJSONArray("messages")!!.length()>0){
                            TroopSocketClient.messageInsertOrUpdate(response.optJSONArray("messages")!!,ConstantValues.SocketOn.SYNC)
                        }
                    }
                }
            }
        }
    }

}
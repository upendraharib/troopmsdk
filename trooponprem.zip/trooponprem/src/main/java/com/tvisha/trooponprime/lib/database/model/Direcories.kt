package com.tvisha.troopmessenger.FileDeck.Model

data class Direcories(
    var folder_id:Int=0,
    var folder_name:String?=null
)

package com.tvisha.trooponprime.lib.clientModels

data class Chats(
    var entity_id:String = "",
    var entity_type:Int = 0,
    var is_archived:Int = 0,
)

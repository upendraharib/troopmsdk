package com.tvisha.trooponprime.lib.database.model

data class NotifyDataModel (
    var workspace_id:String = "",
    var updated_at : String = ""
)
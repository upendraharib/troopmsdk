package com.tvisha.trooponprime.lib.database.model

data class GroupModel(
    var uid:String = "",
    var user_id:Long = 0
)

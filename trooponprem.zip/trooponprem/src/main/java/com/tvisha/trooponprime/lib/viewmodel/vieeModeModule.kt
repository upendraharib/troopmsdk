package com.tvisha.trooponprime.lib.viewmodel

import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module

val viewModeModule = module{
    viewModel { ApiViewModel(get()) }
}
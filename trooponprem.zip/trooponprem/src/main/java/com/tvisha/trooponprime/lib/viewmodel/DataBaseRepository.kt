package com.tvisha.trooponprime.lib.viewmodel

import androidx.lifecycle.LiveData
import androidx.paging.*
import androidx.sqlite.db.SimpleSQLiteQuery
import com.tvisha.trooponprime.lib.TroopMessengerClient.Companion.dataBase
import com.tvisha.trooponprime.lib.clientModels.ConversationModel
import com.tvisha.trooponprime.lib.clientModels.RecentMessageList
import com.tvisha.trooponprime.lib.database.model.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DataBaseRepository @Inject constructor(private val dataBaseViewModel: DataBaseViewModel) {
    /*fun fetchWorkspaceRecentListData():LiveData<List<RecentList>>{
        return dataBase!!.messengerDAO.fetchRecentChatMessageList(SimpleSQLiteQuery(""))
    }
    fun fetchRecentListData():LiveData<List<RecentList>>{
        return dataBase!!.messengerDAO.fetchRecentChatMessageList(SimpleSQLiteQuery(""))
    }
    fun fetchWorkspaceConversation(): Flow<PagingData<Messenger>> {
        return Pager(
            config = PagingConfig(
                pageSize = 50,
                prefetchDistance = 10,
                enablePlaceholders = false,
                initialLoadSize = 50,
                maxSize = 200000
            )
        ) {
            dataBase!!.messengerDAO.fetchMessages(SimpleSQLiteQuery("query"))
        }.flow.map { pagingData ->
            pagingData.map { cheese -> cheese }
        }.cachedIn(dataBaseViewModel!!.viewModelScope).flowOn(Dispatchers.IO)
    }
    fun fetchWorkspaceRecentNotifyMessages():LiveData<List<Notify>>{
        return dataBase!!.notifyDAO.fetchRecentNotifies("")
    }
    fun fetchRecentNotifyMessages():LiveData<List<Notify>>{
        return dataBase!!.notifyDAO.fetchRecentNotifies("")
    }
    fun fetchNotifyMessages():Flow<PagingData<Notify>>{
        return Pager(
            config = PagingConfig(
                pageSize = 50,
                prefetchDistance = 10,
                enablePlaceholders = false,
                initialLoadSize = 50,
                maxSize = 20000
            )
        ) {
            dataBase!!.notifyDAO.fetchNotifies(SimpleSQLiteQuery("query"))
        }.flow.map { pagingData ->
            pagingData.map { cheese -> cheese }
        }.cachedIn(dataBaseViewModel!!.viewModelScope).flowOn(Dispatchers.IO)
    }
    fun fetchDeactivatedUsers():List<RecentList>{
        return dataBase!!.userDAO.fetchDeactivateList(SimpleSQLiteQuery(""))
    }
    fun fetchUsersForGroupCreation():LiveData<List<ContactModel>>{
        return dataBase!!.userDAO.fetchUserListForGroup(SimpleSQLiteQuery(""))
    }
    fun fetchWorkspaceGroupGroupMembers(workspaceId: String,entityId:String):LiveData<List<GroupMembersModel>>{
        return dataBase!!.groupMembersDAO.fetchWorkspaceGroupMembers(workspaceId,entityId)
    }
    fun fetchGroupGroupMembers(entityId:String):LiveData<List<GroupMembersModel>>{
        return dataBase!!.groupMembersDAO.fetchGroupMembers(entityId)
    }
    fun fetchWorkspaceReadReceiptMembers(workspaceId: String,entityId: String):LiveData<List<ContactModel>>{
        return dataBase!!.userDAO.fetchWorkspaceReadReceiptWithOrangeUsers(workspaceId,entityId)
    }
    fun fetchReadReceiptMembers(entityId: String):LiveData<List<ContactModel>>{
        return dataBase!!.userDAO.fetchReadReceiptWithOrangeUsers(entityId)
    }
    fun fetchWorkspaceSelfLinks(workspaceId: String,workspaceUserId:String,burnout:Boolean):LiveData<List<GalleryModel>>{
        return dataBase!!.messengerDAO.fetchWorkspaceSelfLinks(workspaceId,workspaceUserId,if (burnout) 3 else 1)
    }
    fun fetchSelfMediaLinks(loginUserId:String,burnout:Boolean):LiveData<List<GalleryModel>>{
        return dataBase!!.messengerDAO.fetchSelfLinks(loginUserId,if (burnout) 3 else 1)
    }
    fun fetchWorkspaceGroupLinks(workspaceId: String,entityId: String,burnout: Boolean):LiveData<List<GalleryModel>>{
        return dataBase!!.messengerDAO.fetchWorkspaceGroupLinks(workspaceId,entityId,if (burnout) 3 else 1)
    }
    fun fetchGroupLinks(entityId: String,burnout: Boolean):LiveData<List<GalleryModel>>{
        return dataBase!!.messengerDAO.fetchGroupLinks(entityId,if (burnout) 3 else 1)
    }
    fun fetchWorkspaceUserLinks(workspaceId: String,workspaceUserId: String,entityId: String,burnout: Boolean):LiveData<List<GalleryModel>>{
        return dataBase!!.messengerDAO.fetchWorkspaceUserLinks(workspaceId,workspaceUserId,entityId,if (burnout) 3 else 1)
    }
    fun fetchUserLinks(loginUserId: String,entityId: String,burnout: Boolean):LiveData<List<GalleryModel>>{
        return dataBase!!.messengerDAO.fetchUserLinks(loginUserId,entityId,if (burnout) 3 else 1)
    }

    fun fetchWorkspaceSelfMedia(workspaceId: String,workspaceUserId:String,burnout:Boolean,download:List<Int>):LiveData<List<GalleryModel>>{
        return dataBase!!.messengerDAO.fetchWorkspaceSelfMedia(workspaceId,workspaceUserId,if (burnout) 3 else 1,download)
    }
    fun fetchSelfMedia(loginUserId:String,burnout:Boolean,download: List<Int>):LiveData<List<GalleryModel>>{
        return dataBase!!.messengerDAO.fetchSelfMedia(loginUserId,if (burnout) 3 else 1,download)
    }
    fun fetchWorkspaceGroupMedia(workspaceId: String,entityId: String,burnout: Boolean,download: List<Int>):LiveData<List<GalleryModel>>{
        return dataBase!!.messengerDAO.fetchWorkspaceGroupMedia(workspaceId,entityId,if (burnout) 3 else 1,download)
    }
    fun fetchGroupMedia(entityId: String,burnout: Boolean,download: List<Int>):LiveData<List<GalleryModel>>{
        return dataBase!!.messengerDAO.fetchGroupMedia(entityId,if (burnout) 3 else 1,download)
    }
    fun fetchWorkspaceUserMedia(workspaceId: String,workspaceUserId: String,entityId: String,burnout: Boolean,download: List<Int>):LiveData<List<GalleryModel>>{
        return dataBase!!.messengerDAO.fetchWorkspaceUserMedia(workspaceId,workspaceUserId,entityId,if (burnout) 3 else 1,download)
    }
    fun fetchUserMedia(loginUserId: String,entityId: String,burnout: Boolean,download: List<Int>):LiveData<List<GalleryModel>>{
        return dataBase!!.messengerDAO.fetchUserMedia(loginUserId,entityId,if (burnout) 3 else 1,download)
    }

    fun fetchWorkspaceMyDeckFolderTags(folderId:Int,workspaceId:String):LiveData<String>{
        return dataBase!!.myDeckFolderDAO.fetchWorkspaceMyDeckFolderTags(0,workspaceId)
    }
    fun fetchMyDeckFolderTags(folderId:Int):LiveData<String>{
        return dataBase!!.myDeckFolderDAO.fetchMyDeckFolderTags(0)
    }
    fun fetchWorkspaceMyDeckFolderComments(folderId: Int,workspaceId: String):LiveData<List<CommentModel>>{
        return dataBase!!.myDeckFolderDAO.fetchWorkspaceMyDeckFolderComments(folderId,workspaceId)
    }
    fun fetchMyDeckFolderComments(folderId: Int):LiveData<List<CommentModel>>{
        return dataBase!!.myDeckFolderDAO.fetchMyDeckFolderComments(folderId)
    }
    fun fetchWorkspaceMyDeckFileTags(fileId:String,workspaceId: String):LiveData<String>{
        return dataBase!!.myDeckFileDAO.fetchWorkspaceMyDeckFileTags(fileId,workspaceId)
    }
    fun fetchMyDeckFileTags(fileId:String):LiveData<String>{
        return dataBase!!.myDeckFileDAO.fetchMyDeckFileTags(fileId)
    }
    fun fetchWorkspaceMyDeckFileComments(userId:String,fileId:String,workspaceId: String):LiveData<List<CommentModel>>{
        return dataBase!!.myDeckFileDAO.fetchWorkspaceMyDeckFileComments(userId,fileId,workspaceId)
    }
    fun fetchMyDeckFileComments(userId: String,fileId:String):LiveData<List<CommentModel>>{
        return dataBase!!.myDeckFileDAO.fetchMyDeckFileComments(userId,fileId)
    }
    fun fetchWorkspaceMyDeckRootFolderFiles(workspaceId: String):LiveData<List<FileModel>>{
        return dataBase!!.myDeckFolderDAO.fetchWorkspaceUserRootFolderFiles(workspaceId)
    }
    fun fetchMyDeckRootFolderFiles():LiveData<List<FileModel>>{
        return dataBase!!.myDeckFolderDAO.fetchUserRootFolderFiles()
    }
    fun fetchWorkspaceUserRootFolder(workspaceId: String):LiveData<List<FolderModel>>{
        return dataBase!!.myDeckFolderDAO.fetchWorkspaceUserRootFolder(workspaceId)
    }
    fun fetchUserRootFolder():LiveData<List<FolderModel>>{
        return dataBase!!.myDeckFolderDAO.fetchUserRootFolder()
    }
    fun fetchWorkspaceFileDeckDeckFileTags(messageId:Long,workspaceId: String):LiveData<String>{
        return dataBase!!.fileDeckMetaDAO.fetchWorkspaceMyFileTags(messageId,workspaceId)
    }
    fun fetchFileDeckFileTags(messageId: Long):LiveData<String>{
        return dataBase!!.fileDeckMetaDAO.fetchMyFileTags(messageId)
    }
    fun fetchWorkspaceFileDeckFileComments(messageId: Long,workspaceId: String):LiveData<List<CommentModel>>{
        return dataBase!!.fileDeckMetaDAO.fetchWorkspaceMyFileComments(messageId,workspaceId)
    }
    fun fetchFileDeckFileComments(messageId: Long):LiveData<List<CommentModel>>{
        return dataBase!!.fileDeckMetaDAO.fetchMyFileComments(messageId)
    }
    fun fetchFileDeckList(workspaceUserId: String,workspaceId: String,searchText:String,searchMessage:Boolean):LiveData<List<RecentList>>{
        return dataBase!!.fileDeckMetaDAO.fetchRecentTmList(SimpleSQLiteQuery(""))
    }
    fun updateUnreadReadReceiptRespondLaterCount(isUserGroup:Int,loginUserId: String,workspaceId: String,entityId: String){
        val unreadCount  = if (isUserGroup==ConstantValues.IS_USER_CONVERSATION){
            dataBase!!.messengerDAO.fetchUserUnreadCount(entityId,loginUserId)
        }else{
            dataBase!!.messengerDAO.fetchGroupUnreadCount(loginUserId,entityId)
        }
        val readReceiptCount = if (isUserGroup==ConstantValues.IS_USER_CONVERSATION){
            dataBase!!.messengerDAO.fetchUserUnreadReadReceiptCount(loginUserId,entityId)
        }else {
            dataBase!!.messengerDAO.fetchGroupUnreadReadReceiptCount(loginUserId,entityId)
        }
        val respondLaterCount = if (isUserGroup==ConstantValues.IS_USER_CONVERSATION){
            dataBase!!.messengerDAO.fetchUserRespondLaterCount(loginUserId,entityId)
        }else{
            dataBase!!.messengerDAO.fetchGroupRespondLaterCount(loginUserId,entityId)
        }
        if (isUserGroup==ConstantValues.IS_USER_CONVERSATION){
            dataBase!!.userDAO.updateUserUnreadCount(unreadCount,entityId)
            dataBase!!.userDAO.updateUserReadReceiptCount(readReceiptCount,entityId)
            dataBase!!.userDAO.updateUserRespondLaterCount(respondLaterCount,entityId)
        }else{
            dataBase!!.messengerGroupDAO.updateGroupUnreadCount(unreadCount,entityId)
            dataBase!!.messengerGroupDAO.updateGroupReadReceiptCount(readReceiptCount,entityId)
            dataBase!!.messengerGroupDAO.updateGroupRespondLaterCount(respondLaterCount,entityId)
        }
    }*/
    /*fun fetchRecentMessages():LiveData<List<RecentMessageList>>{
        var query = "SELECT last_message_local_id as id,last_message_id as message_id,last_message as message,last_message_type as message_type,last_message_status as message_status,last_message_by_me as is_sender, unread_messages_count,last_message_sender_name as sender_name,last_message_sender_id as  sender_id,user_id as entity_id,1 as entity,name as entity_name,profile_pic as entity_avatar,last_message_time as message_time FROM user WHERE last_message_id !=0 AND is_archived = 0 UNION SELECT last_message_local_id as id,last_message_id as message_id,last_message as message,last_message_type as message_type,last_message_status as message_status,last_message_by_me as is_sender, unread_messages_count,last_message_sender_name as sender_name,last_message_sender_id as sender_id,group_id as entity_id,2 as entity,group_name as entity_name,group_avatar as entity_avatar,last_message_time as message_time FROM chat_group WHERE last_message_id !=0 AND is_active = 1 AND is_archived = 0 ORDER BY message_time DESC"
        return dataBase!!.messengerDAO.fetchRecentMessageList(SimpleSQLiteQuery(query))
    }
    fun fetchArchivedList():LiveData<List<RecentMessageList>>{
        var query = "SELECT last_message_local_id as id,last_message_id as message_id,last_message as message,last_message_type as message_type,last_message_status as message_status,last_message_by_me as is_sender, unread_messages_count,last_message_sender_name as sender_name,last_message_sender_id as  sender_id,user_id as entity_id,1 as entity,name as entity_name,profile_pic as entity_avatar,last_message_time as message_time FROM user WHERE last_message_id !=0 AND is_archived = 1 UNION SELECT last_message_local_id as id,last_message_id as message_id,last_message as message,last_message_type as message_type,last_message_status as message_status,last_message_by_me as is_sender, unread_messages_count,last_message_sender_name as sender_name,last_message_sender_id as sender_id,group_id as entity_id,2 as entity,group_name as entity_name,group_avatar as entity_avatar,last_message_time as message_time FROM chat_group WHERE last_message_id !=0 AND is_active = 1 AND is_archived = 1 ORDER BY message_time DESC"
        return dataBase!!.messengerDAO.fetchArchivedList(SimpleSQLiteQuery(query))
    }*/
    fun fetchForwardList():LiveData<List<ForwardModel>>{
        var query = "SELECT user_id as entity_id,1 as entity,name as entity_name,profile_pic as entity_avatar,last_message_time as message_time FROM user WHERE last_message_local_id !=0 AND is_blocked = 0 UNION SELECT group_id as entity_id,2 as entity,group_name as entity_name,group_avatar as entity_avatar,last_message_time as message_time FROM chat_group WHERE last_message_local_id!=0 AND is_active = 1 ORDER BY message_time DESC"
        return dataBase!!.messengerDAO.fetchForwardList(SimpleSQLiteQuery(query))
    }
    fun fetchConversation(userId:String,entityId:String,entity:Int):PagingSource<Int, ConversationModel>{
        var query = ""
        if (entity==1){
            query = "SELECT m.ID,LOWER(replace(m.attachment,rtrim(m.attachment,replace(m.attachment,'.','')),'')) as attachment_extension,m.original_message,m.is_forkout,m.is_forward,m.preview_link,m.status,m.message_id,CASE WHEN status = 2 THEN '' ELSE m.message END as message,m.sender_id,m.receiver_id,m.message_type,m.is_reply,m.original_message_id,m.attachment,m.is_read,m.is_delivered,m.caption,m.is_group,m.created_at,m.attachment_downloaded,m.attachment_path,'' as member_name FROM chat as m WHERE (m.sender_id=$userId AND receiver_id=$entityId AND m.is_group=0) or (m.sender_id = $entityId AND m.receiver_id=$userId AND m.is_group=0) GROUP BY m.ID HAVING m.status IN (1,2) ORDER BY m.created_at DESC,m.message_id DESC"
        }else{
            query = "SELECT m.ID,LOWER(replace(m.attachment,rtrim(m.attachment,replace(m.attachment,'.','')),'')) as attachment_extension,m.original_message,m.is_forkout,m.is_forward,m.preview_link,m.status,m.message_id,CASE WHEN status = 2 THEN '' ELSE m.message END as message,m.sender_id,m.receiver_id,m.message_type,m.is_reply,m.original_message_id,m.attachment,m.is_read,m.is_delivered,m.caption,m.is_group,m.created_at,m.attachment_downloaded,m.attachment_path,u.name as member_name FROM chat as m LEFT JOIN user as u ON m.sender_id = u.user_id LEFT JOIN group_member as mgm ON mgm.group_id=m.receiver_id AND mgm.user_id = m.sender_id WHERE (m.receiver_id=$entityId AND m.is_group=1) or (m.sender_id = $userId AND m.receiver_id=$entityId AND m.is_group=1) GROUP BY m.ID HAVING m.status IN (1,2) ORDER BY m.created_at DESC,m.message_id DESC"
        }
        return dataBase!!.messengerDAO.fetchConversationMessages(SimpleSQLiteQuery(query))
    }
    fun fetchUserRecentMessages(userId:String):List<RecentLastMessage>{
        var query = "SELECT max(id) as id,message_id,m.sender_name as member_name,CASE WHEN is_sync=0 THEN 0 WHEN status=2 THEN 4 WHEN is_read = 1 THEN 1 ELSE 2 END as message_status,CASE WHEN sender_id=$userId THEN 1 ELSE 0 END as is_sender,sum(CASE WHEN receiver_id =$userId AND is_read = 0 THEN 1 ELSE 0 END) as unread_messages_count,CASE WHEN sender_id > receiver_id THEN sender_id || '_' || receiver_id ELSE receiver_id || '_' || sender_id END as contact_id,sender_id,receiver_id,CASE WHEN sender_id =$userId THEN receiver_id ELSE sender_id END as entity_id,CASE WHEN status=2 THEN '' ELSE message END as message,message_type,created_at FROM chat WHERE is_group = 0 GROUP BY contact_id ORDER BY created_at DESC"
        return dataBase!!.messengerDAO.fetchUserOrGroupRecentMessageList(SimpleSQLiteQuery(query))
    }
    fun fetchGroupRecentMessages(userId:String):List<RecentLastMessage>{
        var query = "SELECT max(c.id) as id,IFNULL(u.user_id,0) as member_id,IFNULL(u.name, '') as member_name,c.message_id,CASE WHEN c.is_sync=0 THEN 0 WHEN c.status=2 THEN 4 WHEN c.is_read = 1 THEN 1 ELSE 2 END as message_status,CASE WHEN c.sender_id=$userId THEN 1 ELSE 0 END as is_sender,sum(CASE WHEN c.receiver_id =$userId AND c.is_read = 0 THEN 1 ELSE 0 END) as unread_messages_count,c.sender_id,c.receiver_id,c.receiver_id as entity_id,CASE WHEN c,status=2 THEN '' ELSE c.message END as message,c.message_type,c.created_at FROM chat as c LEFT JOIN user as u ON u.user_id=c.sender_id WHERE c.is_group = 1 GROUP BY c.receiver_id ORDER BY c.created_at DESC"
        return dataBase!!.messengerDAO.fetchUserOrGroupRecentMessageList(SimpleSQLiteQuery(query))
    }


}
package com.tvisha.trooponprime.lib.viewmodel

import android.util.Log
import com.google.gson.Gson
import com.iq.atoms.data.base.ResponseResult
import com.tvisha.trooponprime.lib.TroopClient
import com.tvisha.trooponprime.lib.TroopMessengerClient.Companion.APPLICATION_TM_LOGIN_USER_ID
import com.tvisha.trooponprime.lib.TroopMessengerClient.Companion.APP_ACCESS_TOKEN
import com.tvisha.trooponprime.lib.TroopMessengerClient.Companion.APP_AUTHORIZATION_TOKEN
import com.tvisha.trooponprime.lib.TroopMessengerClient.Companion.messengerSocket
import com.tvisha.trooponprime.lib.api.BaseAPIService
import com.tvisha.trooponprime.lib.api.BaseRetrofitClient
import com.tvisha.trooponprime.lib.utils.ConstantValues
import org.json.JSONArray
import org.json.JSONObject
import org.junit.runner.Description
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.await
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ApiRepository @Inject constructor(private var baseAPIService: BaseAPIService) {

    /*suspend fun login():ResponseResult<String>{
        return try {
            var response = baseAPIService.tmLoginApi(JSONObject()).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{
                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }


    suspend fun callLoginApi() {
        *//*var response = baseAPIService.messengerLogin("","","",ConstantValues.DEVICE_TYPE_ANDROID,ConstantValues.PLATFORM_ANDROID).await()
        var responseResult = response.toString()*//*
        *//*return try {*//*

            BaseRetrofitClient.instance.messengerLogin("","","",ConstantValues.DEVICE_TYPE_ANDROID,ConstantValues.PLATFORM_ANDROID)
                .enqueue(object :Callback<String>{
                    override fun onResponse(call: Call<String>, response: Response<String>) {
                        if (response.isSuccessful) {
                            ResponseResult.Success(response.body()!!)
                        }else{
                            ResponseResult.Error("Error")
                        }
                    }
                    override fun onFailure(call: Call<String>, t: Throwable) {
                        ResponseResult.Error("Error")
                    }
                })
        *//*}catch (e:Exception){
            ResponseResult.Error("something went wrong")
        }*//*

    }
    suspend fun createGroup(){
        SocketAppRetrofitClient.instance.createNewGroup("","",1, JSONArray(),"","","","",ConstantValues.DEVICE_TYPE_ANDROID,ConstantValues.PLATFORM_ANDROID)
            .enqueue(object : Callback<String>{
                override fun onResponse(call: Call<String>, response: Response<String>) {
                    if (response.isSuccessful){
                        ResponseResult.Success(response.body()!!)
                    }else{
                        ResponseResult.Error("")
                    }
                }
                override fun onFailure(call: Call<String>, t: Throwable) {
                    ResponseResult.Error("")
                }
            })
    }
    suspend fun updateGroupName(){
        SocketAppRetrofitClient.instance.updateGroupData("","","","","",ConstantValues.DEVICE_TYPE_ANDROID,ConstantValues.PLATFORM_ANDROID)
            .enqueue(object :Callback<String>{
                override fun onResponse(call: Call<String>, response: Response<String>) {
                    if (response.isSuccessful){
                        ResponseResult.Success(response.body()!!)
                    }else{
                        ResponseResult.Error("")
                    }
                }

                override fun onFailure(call: Call<String>, t: Throwable) {
                    ResponseResult.Error("")
                }
            })
    }
    suspend fun addGroupMembers(){
        SocketAppRetrofitClient.instance.addGroupMembers("","","","",JSONArray(),ConstantValues.DEVICE_TYPE_ANDROID,ConstantValues.PLATFORM_ANDROID)
            .enqueue(object :Callback<String>{
                override fun onResponse(call: Call<String>, response: Response<String>) {
                    if (response.isSuccessful){
                        ResponseResult.Success(response.body()!!)
                    }else{
                        ResponseResult.Error("")
                    }
                }

                override fun onFailure(call: Call<String>, t: Throwable) {
                    ResponseResult.Error("")
                }
            })
    }
    suspend fun removeGroupUser(){

    }
    suspend fun makeGroupAdmin(){

    }
    suspend fun makeGroupModerator(){

    }
    suspend fun exitFromGroup(){

    }
    suspend fun deleteGroup(){

    }
    suspend fun groupData(){
        SocketAPIRetrofitClient.instance.getTheGroupData("",0,"",ConstantValues.DEVICE_TYPE_ANDROID,ConstantValues.PLATFORM_ANDROID)
            .enqueue(object :Callback<String>{
                override fun onResponse(call: Call<String>, response: Response<String>) {
                    if (response.isSuccessful){
                        ResponseResult.Success(response.body()!!)
                    }else{
                        ResponseResult.Error("")
                    }
                }

                override fun onFailure(call: Call<String>, t: Throwable) {
                    ResponseResult.Error("")
                }
            })
    }*/
    suspend fun fetchAllMessages():ResponseResult<String>{ //done
        return try {
            var response = baseAPIService.fetchAllMessages(ConstantValues.CLIENT_VERSION,APPLICATION_TM_LOGIN_USER_ID,APP_AUTHORIZATION_TOKEN,ConstantValues.TOKEN,ConstantValues.PLATFORM_ANDROID,ConstantValues.DEVICE_TYPE_ANDROID).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{
                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }
    suspend fun syncUpdatedContacts(recentTime:String):ResponseResult<String>{
        return try {
            var response = baseAPIService.fetchUpdateMessengerContacts(ConstantValues.CLIENT_VERSION,if (messengerSocket!=null && messengerSocket!!.connected()) messengerSocket!!.id() else "",
                APPLICATION_TM_LOGIN_USER_ID,APP_AUTHORIZATION_TOKEN,ConstantValues.TOKEN,ConstantValues.PLATFORM_ANDROID,ConstantValues.DEVICE_TYPE_ANDROID,recentTime).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{
                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }
    suspend fun syncServerMessages(recentTime:String):ResponseResult<String>{
        return try {
            var response = baseAPIService.fetchOfflineMessages(ConstantValues.CLIENT_VERSION,if (messengerSocket!=null && messengerSocket!!.connected()) messengerSocket!!.id() else "",
                APPLICATION_TM_LOGIN_USER_ID,APP_AUTHORIZATION_TOKEN,ConstantValues.TOKEN,ConstantValues.PLATFORM_ANDROID,ConstantValues.DEVICE_TYPE_ANDROID,recentTime,"").await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{

                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }
    suspend fun fetchAllStories():ResponseResult<String>{
        return try {
            var response = baseAPIService.fetchAllStories(ConstantValues.CLIENT_VERSION,APPLICATION_TM_LOGIN_USER_ID,APP_AUTHORIZATION_TOKEN,ConstantValues.TOKEN,ConstantValues.PLATFORM_ANDROID,ConstantValues.DEVICE_TYPE_ANDROID).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{

                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }
    suspend fun updateFcm(fcmToken:String):ResponseResult<String>{
        return try {
            var response = baseAPIService.updateFCMToken(ConstantValues.CLIENT_VERSION,APPLICATION_TM_LOGIN_USER_ID,ConstantValues.TOKEN,"1",fcmToken).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{

                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }
    suspend fun deleteFcm(fcmToken:String):ResponseResult<String>{
        return try {
            var response = baseAPIService.deleteFCMToken(ConstantValues.CLIENT_VERSION,APPLICATION_TM_LOGIN_USER_ID,ConstantValues.TOKEN,"0",fcmToken).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{

                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }
    suspend fun updateUserProfilePic(profilePic:String):ResponseResult<String>{
        return try {
            var response = baseAPIService.updateProfilePic(ConstantValues.CLIENT_VERSION,if (messengerSocket!=null && messengerSocket!!.connected()) messengerSocket!!.id() else "",
                APPLICATION_TM_LOGIN_USER_ID,ConstantValues.TOKEN,APP_AUTHORIZATION_TOKEN,APP_ACCESS_TOKEN,profilePic).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{

                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }
    suspend fun fetchUserProfileBuUid(initiatorUid:String):ResponseResult<String>{
        return try {
            var response = baseAPIService.fetchUserProfilePicByUid(ConstantValues.CLIENT_VERSION,if (messengerSocket!=null && messengerSocket!!.connected()) messengerSocket!!.id() else "",
                initiatorUid,ConstantValues.TOKEN,APP_AUTHORIZATION_TOKEN,APP_ACCESS_TOKEN).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{

                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }
    suspend fun fetchDeactivatedUsers(recentTime: String):ResponseResult<String>{
        return try {
            var response = baseAPIService.fetchDeactivatedUsers(ConstantValues.CLIENT_VERSION,if (messengerSocket!=null && messengerSocket!!.connected()) messengerSocket!!.id() else "",
                APPLICATION_TM_LOGIN_USER_ID,ConstantValues.TOKEN,APP_AUTHORIZATION_TOKEN,APP_ACCESS_TOKEN,recentTime).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{

                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }
    suspend fun fetchAllBroadCastMessages():ResponseResult<String>{
        return try {
            var response = baseAPIService.fetchAllBroadCastMessages(ConstantValues.CLIENT_VERSION,APPLICATION_TM_LOGIN_USER_ID,ConstantValues.TOKEN,APP_AUTHORIZATION_TOKEN).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{

                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }
    suspend fun syncBroadCastMessages(recentTime: String):ResponseResult<String>{
        return try {
            var response = baseAPIService.fetchUpdatedBroadCastMessages(ConstantValues.CLIENT_VERSION,if (messengerSocket!=null && messengerSocket!!.connected()) messengerSocket!!.id() else "",
                APPLICATION_TM_LOGIN_USER_ID,ConstantValues.TOKEN,APP_AUTHORIZATION_TOKEN,APP_ACCESS_TOKEN,recentTime).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{

                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }
    suspend fun syncStories(recentTime:String):ResponseResult<String>{
        return try {
            var response = baseAPIService.fetchUpdatedStories(ConstantValues.CLIENT_VERSION,if (messengerSocket!=null && messengerSocket!!.connected()) messengerSocket!!.id() else "",
                APPLICATION_TM_LOGIN_USER_ID,APP_AUTHORIZATION_TOKEN,APP_ACCESS_TOKEN,ConstantValues.TOKEN,ConstantValues.PLATFORM_ANDROID,ConstantValues.DEVICE_TYPE_ANDROID,recentTime).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{

                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }
    
    
    suspend fun register(token:String,uid:String,name:String,mobileNumber:String,countryCode:String):ResponseResult<String>{
        return try {
            var response = baseAPIService.registerTm(ConstantValues.CLIENT_VERSION,token,uid,name,mobileNumber,countryCode).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{

                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
        /*BaseRetrofitClient.instance.registerTm(token,uid,name,mobileNumber,countryCode)
            .enqueue(object :Callback<String>{
                override fun onResponse(call: Call<String>, response: Response<String>) {
                    if (response.isSuccessful){
                        ResponseResult.Success(response.body()!!)
                    }else{
                        ResponseResult.Error("")
                    }
                }
                override fun onFailure(call: Call<String>, t: Throwable) {
                    ResponseResult.Error("")
                }
            })*/
    }
    suspend fun syncContacts(token: String,userId:String,at:String,contacts:String,deviceId:String,platForm:Int):ResponseResult<String>{
        return try {
            var response = baseAPIService.syncContacts(ConstantValues.CLIENT_VERSION,userId,at,token,platForm,contacts,deviceId).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{

                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }

    suspend fun saveContact(contactName:String,entityId:String){

    }
    suspend fun fetchChatList(conversationUserId:String):ResponseResult<String>{
        return try {
            var response = baseAPIService.fetchChatList(ConstantValues.CLIENT_VERSION,messengerSocket!!.id(),APPLICATION_TM_LOGIN_USER_ID,APP_ACCESS_TOKEN,ConstantValues.TOKEN,conversationUserId).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{
                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }
    suspend fun createGroup(groupName:String,groupAvatar:String,groupDescription: String,conversationUserId:String,members:JSONArray):ResponseResult<String>{
        return try {
            var responseObject = JSONObject()
            if (groupName.isNullOrEmpty()){
                responseObject.put("success",false)
                responseObject.put("message","Group Name is required")
                ResponseResult.Error(responseObject.toString())
            }
            if (members.length()==0){
                responseObject.put("success",false)
                responseObject.put("message","Group members are required")
                ResponseResult.Error(responseObject.toString())
            }
            var response = baseAPIService.createGroup(ConstantValues.CLIENT_VERSION,if (messengerSocket!=null && messengerSocket!!.connected()) messengerSocket!!.id() else "",
                APPLICATION_TM_LOGIN_USER_ID,APP_ACCESS_TOKEN,ConstantValues.TOKEN,groupName,groupDescription,groupAvatar,members.toString(),ConstantValues.PLATFORM_ANDROID,conversationUserId).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{
                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }
    suspend fun updateGroupName(groupId:String,groupName: String):ResponseResult<String>{
        return try {
            var responseObject = JSONObject()
            if (groupName.isNullOrEmpty()){
                responseObject.put("success",false)
                responseObject.put("message","Invalid Group Name")
                ResponseResult.Error(responseObject.toString())
            }
            if (groupId.isNullOrEmpty()){
                responseObject.put("success",false)
                responseObject.put("message","Invalid Group")
                ResponseResult.Error(responseObject.toString())
            }
            var response = baseAPIService.updateGroupName(ConstantValues.CLIENT_VERSION,if (messengerSocket!=null && messengerSocket!!.connected()) messengerSocket!!.id() else "",
                ConstantValues.GroupUpdatePayLoads.PAYLOAD_CHANGE_NAME,groupId,APPLICATION_TM_LOGIN_USER_ID,APP_ACCESS_TOKEN,ConstantValues.TOKEN,groupName,ConstantValues.PLATFORM_ANDROID).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{
                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }
    suspend fun updateGroupAvtar(groupAvatar: String,groupId: String):ResponseResult<String>{
        return try {
            var responseObject = JSONObject()
            if (groupId.isNullOrEmpty()){
                responseObject.put("success",false)
                responseObject.put("message","Invalid Group")
                ResponseResult.Error(responseObject.toString())
            }
            var response = baseAPIService.updateGroupAvatar(ConstantValues.CLIENT_VERSION,if (messengerSocket!=null && messengerSocket!!.connected()) messengerSocket!!.id() else "",
                ConstantValues.GroupUpdatePayLoads.PAYLOAD_CHANGE_AVATAR,groupId,APPLICATION_TM_LOGIN_USER_ID,APP_ACCESS_TOKEN,ConstantValues.TOKEN,groupAvatar,ConstantValues.PLATFORM_ANDROID).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{
                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }
    suspend fun makeGroupAdmin(groupId: String,memberId:String):ResponseResult<String>{
        var responseObject = JSONObject()
        if (groupId.isNullOrEmpty()){
            responseObject.put("success",false)
            responseObject.put("message","Invalid Group")
            ResponseResult.Error(responseObject.toString())
        }
        if (memberId.isNullOrEmpty()){
            responseObject.put("success",false)
            responseObject.put("message","Invalid member")
            ResponseResult.Error(responseObject.toString())
        }
        return updateGroupMemberRole(groupId,memberId,ConstantValues.GroupValues.ADMIN)
    }
    suspend fun makeGroupModerator(groupId: String,memberId:String):ResponseResult<String>{
        var responseObject = JSONObject()
        if (groupId.isNullOrEmpty()){
            responseObject.put("success",false)
            responseObject.put("message","Invalid Group")
            ResponseResult.Error(responseObject.toString())
        }
        if (memberId.isNullOrEmpty()){
            responseObject.put("success",false)
            responseObject.put("message","Invalid member")
            ResponseResult.Error(responseObject.toString())
        }
        return updateGroupMemberRole(groupId,memberId,ConstantValues.GroupValues.MODERATOR)
    }
    suspend fun removeGroupAdmin(groupId: String,memberId:String):ResponseResult<String>{
        var responseObject = JSONObject()
        if (groupId.isNullOrEmpty()){
            responseObject.put("success",false)
            responseObject.put("message","Invalid Group")
            ResponseResult.Error(responseObject.toString())
        }
        if (memberId.isNullOrEmpty()){
            responseObject.put("success",false)
            responseObject.put("message","Invalid member")
            ResponseResult.Error(responseObject.toString())
        }
        return updateGroupMemberRole(groupId,memberId,ConstantValues.GroupValues.MEMBER)
    }
    suspend fun removeGroupModerator(groupId: String,memberId:String):ResponseResult<String>{
        var responseObject = JSONObject()
        if (groupId.isNullOrEmpty()){
            responseObject.put("success",false)
            responseObject.put("message","Invalid Group")
            ResponseResult.Error(responseObject.toString())
        }
        if (memberId.isNullOrEmpty()){
            responseObject.put("success",false)
            responseObject.put("message","Invalid member")
            ResponseResult.Error(responseObject.toString())
        }
        return updateGroupMemberRole(groupId,memberId,ConstantValues.GroupValues.MEMBER)
    }
    private suspend fun updateGroupMemberRole(groupId: String,memberId: String,memberRole:String):ResponseResult<String>{
        return try {
            var response = baseAPIService.updateGroupUserRole(ConstantValues.CLIENT_VERSION,if (messengerSocket!=null && messengerSocket!!.connected()) messengerSocket!!.id() else "",
                ConstantValues.GroupUpdatePayLoads.PAYLOAD_CHANGE_ROLE,groupId,memberId,APPLICATION_TM_LOGIN_USER_ID,APP_ACCESS_TOKEN,ConstantValues.TOKEN,memberRole,ConstantValues.PLATFORM_ANDROID).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{
                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }
    suspend fun removeGroupUser(groupId: String,memberId: String):ResponseResult<String>{
        return try {
            var responseObject = JSONObject()
            if (groupId.isNullOrEmpty()){
                responseObject.put("success",false)
                responseObject.put("message","Invalid Group")
                ResponseResult.Error(responseObject.toString())
            }
            if (memberId.isNullOrEmpty()){
                responseObject.put("success",false)
                responseObject.put("message","Invalid member")
                ResponseResult.Error(responseObject.toString())
            }
            var response = baseAPIService.removeGroupUser(ConstantValues.CLIENT_VERSION,if (messengerSocket!=null && messengerSocket!!.connected()) messengerSocket!!.id() else "",
                ConstantValues.GroupUpdatePayLoads.PAYLOAD_REMOVE_MEMBERS,groupId,APPLICATION_TM_LOGIN_USER_ID,APP_ACCESS_TOKEN,ConstantValues.TOKEN,memberId,ConstantValues.PLATFORM_ANDROID).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{
                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }
    suspend fun deleteGroup(groupId: String):ResponseResult<String>{
        return try {
            var responseObject = JSONObject()
            if (groupId.isNullOrEmpty()){
                responseObject.put("success",false)
                responseObject.put("message","Invalid Group")
                ResponseResult.Error(responseObject.toString())
            }

            var response = baseAPIService.deleteGroup(ConstantValues.CLIENT_VERSION,if (messengerSocket!=null && messengerSocket!!.connected()) messengerSocket!!.id() else "",
                ConstantValues.GroupUpdatePayLoads.PAYLOAD_GROUP_DELETE,groupId,APPLICATION_TM_LOGIN_USER_ID,APP_ACCESS_TOKEN,ConstantValues.TOKEN,"1",ConstantValues.PLATFORM_ANDROID).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{
                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }
    suspend fun exitGroup(groupId: String):ResponseResult<String>{
        return try {
            var responseObject = JSONObject()
            if (groupId.isNullOrEmpty()){
                responseObject.put("success",false)
                responseObject.put("message","Invalid Group")
                ResponseResult.Error(responseObject.toString())
            }
            var response = baseAPIService.exitGroup(ConstantValues.CLIENT_VERSION,if (messengerSocket!=null && messengerSocket!!.connected()) messengerSocket!!.id() else "",
                ConstantValues.GroupUpdatePayLoads.PAYLOAD_GROUP_EXIT,groupId,APPLICATION_TM_LOGIN_USER_ID,APP_ACCESS_TOKEN,ConstantValues.TOKEN,ConstantValues.PLATFORM_ANDROID).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{
                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }
    suspend fun addGroupMembers(groupId: String,members: JSONArray):ResponseResult<String>{
        return try {
            var responseObject = JSONObject()
            if (groupId.isNullOrEmpty()){
                responseObject.put("success",false)
                responseObject.put("message","Invalid Group")
                ResponseResult.Error(responseObject.toString())
            }
            if (members.length()==0){
                responseObject.put("success",false)
                responseObject.put("message","Group members are required")
                ResponseResult.Error(responseObject.toString())
            }
            var response = baseAPIService.addGroupMembers(ConstantValues.CLIENT_VERSION,if (messengerSocket!=null && messengerSocket!!.connected()) messengerSocket!!.id() else "",
                groupId,APPLICATION_TM_LOGIN_USER_ID,APP_ACCESS_TOKEN,ConstantValues.TOKEN,members,ConstantValues.PLATFORM_ANDROID).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{
                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }
    suspend fun createRoom(roomName:String,roomDescription: String,roomAvatar:String,conversationReferenceId:String):ResponseResult<String>{
        return try {
            var responseObject = JSONObject()
            if (roomName.isNullOrEmpty()){
                responseObject.put("success",false)
                responseObject.put("message","Room Name is required")
                ResponseResult.Error(responseObject.toString())
            }

            var response = baseAPIService.createRoom(ConstantValues.CLIENT_VERSION,if (messengerSocket!=null && messengerSocket!!.connected()) messengerSocket!!.id() else "",
                APPLICATION_TM_LOGIN_USER_ID,APP_ACCESS_TOKEN,ConstantValues.TOKEN,ConstantValues.PLATFORM_ANDROID,conversationReferenceId,roomName,roomDescription,roomAvatar).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{
                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }
    suspend fun updateRoomName(roomId:String,roomName: String):ResponseResult<String>{
        return try {
            var responseObject = JSONObject()
            if (roomId.isNullOrEmpty()){
                responseObject.put("success",false)
                responseObject.put("message","Invalid Room")
                ResponseResult.Error(responseObject.toString())
            }
            if (roomName.isNullOrEmpty()){
                responseObject.put("success",false)
                responseObject.put("message","Room Name is required")
                ResponseResult.Error(responseObject.toString())
            }

            var response = baseAPIService.updateRoomName(ConstantValues.CLIENT_VERSION,if (messengerSocket!=null && messengerSocket!!.connected()) messengerSocket!!.id() else "",
                APPLICATION_TM_LOGIN_USER_ID,APP_ACCESS_TOKEN,ConstantValues.TOKEN,ConstantValues.PLATFORM_ANDROID,ConstantValues.RoomPayloads.ROOM_NAME_CHANGE,roomName,roomId).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{
                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }
    suspend fun updateRoomAvatar(roomId:String,roomAvatar: String):ResponseResult<String>{
        return try {

            var responseObject = JSONObject()
            if (roomId.isNullOrEmpty()){
                responseObject.put("success",false)
                responseObject.put("message","Invalid Room")
                ResponseResult.Error(responseObject.toString())
            }

            var response = baseAPIService.updateRoomAvatar(ConstantValues.CLIENT_VERSION,if (messengerSocket!=null && messengerSocket!!.connected()) messengerSocket!!.id() else "",
                APPLICATION_TM_LOGIN_USER_ID,APP_ACCESS_TOKEN,ConstantValues.TOKEN,ConstantValues.PLATFORM_ANDROID,ConstantValues.RoomPayloads.ROOM_AVATAR_CHANGE,roomId,roomAvatar).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{
                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }
    suspend fun deleteRoom(roomId:String):ResponseResult<String>{
        return try {

            var responseObject = JSONObject()
            if (roomId.isNullOrEmpty()){
                responseObject.put("success",false)
                responseObject.put("message","Invalid Room")
                ResponseResult.Error(responseObject.toString())
            }

            var response = baseAPIService.deleteRoom(ConstantValues.CLIENT_VERSION,if (messengerSocket!=null && messengerSocket!!.connected()) messengerSocket!!.id() else "",
                APPLICATION_TM_LOGIN_USER_ID,APP_ACCESS_TOKEN,ConstantValues.TOKEN,ConstantValues.PLATFORM_ANDROID,ConstantValues.RoomPayloads.ROOM_DELETE,roomId).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{
                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }
    suspend fun exitRoom(roomId:String):ResponseResult<String>{
        return try {

            var responseObject = JSONObject()
            if (roomId.isNullOrEmpty()){
                responseObject.put("success",false)
                responseObject.put("message","Invalid Room")
                ResponseResult.Error(responseObject.toString())
            }

            var response = baseAPIService.exitRoom(ConstantValues.CLIENT_VERSION,if (messengerSocket!=null && messengerSocket!!.connected()) messengerSocket!!.id() else "",
                APPLICATION_TM_LOGIN_USER_ID,APP_ACCESS_TOKEN,ConstantValues.TOKEN,ConstantValues.PLATFORM_ANDROID,ConstantValues.RoomPayloads.ROOM_EXIT,roomId).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{
                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }
    suspend fun fetchRoomDetails(roomId:String):ResponseResult<String>{
        return try {

            var responseObject = JSONObject()
            if (roomId.isNullOrEmpty()){
                responseObject.put("success",false)
                responseObject.put("message","Invalid Room")
                ResponseResult.Error(responseObject.toString())
            }

            var response = baseAPIService.fetchRoomDetails(ConstantValues.CLIENT_VERSION,if (messengerSocket!=null && messengerSocket!!.connected()) messengerSocket!!.id() else "",
                APPLICATION_TM_LOGIN_USER_ID,APP_ACCESS_TOKEN,ConstantValues.TOKEN,ConstantValues.PLATFORM_ANDROID,roomId).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{
                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }
    suspend fun joinRoom(roomId:String):ResponseResult<String>{
        return try {

            var responseObject = JSONObject()
            if (roomId.isNullOrEmpty()){
                responseObject.put("success",false)
                responseObject.put("message","Invalid Room")
                ResponseResult.Error(responseObject.toString())
            }

            var response = baseAPIService.joinRoom(ConstantValues.CLIENT_VERSION,if (messengerSocket!=null && messengerSocket!!.connected()) messengerSocket!!.id() else "",
                APPLICATION_TM_LOGIN_USER_ID,APP_ACCESS_TOKEN,ConstantValues.TOKEN,ConstantValues.PLATFORM_ANDROID,ConstantValues.RoomPayloads.JOIN_ROOM,roomId,APPLICATION_TM_LOGIN_USER_ID).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{
                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }
    suspend fun fetchRoomList():ResponseResult<String>{
        return try {
            var response = baseAPIService.fetchRooms(ConstantValues.CLIENT_VERSION,if (messengerSocket!=null && messengerSocket!!.connected()) messengerSocket!!.id() else "",
                APPLICATION_TM_LOGIN_USER_ID,APP_ACCESS_TOKEN,ConstantValues.TOKEN,ConstantValues.PLATFORM_ANDROID).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{
                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }
    suspend fun addContact(uid:String,name: String):ResponseResult<String>{
        return try {
            var responseObject = JSONObject()
            if (uid.isNullOrEmpty() || name.isNullOrEmpty()){
                responseObject.put("success",false)
                responseObject.put("message","Invalid data")
                ResponseResult.Error(responseObject.toString())
            }
            var response = baseAPIService.addNewContact(ConstantValues.CLIENT_VERSION,if (messengerSocket!=null && messengerSocket!!.connected()) messengerSocket!!.id() else "",
                APPLICATION_TM_LOGIN_USER_ID,APP_AUTHORIZATION_TOKEN,APP_ACCESS_TOKEN,ConstantValues.TOKEN,uid,name,ConstantValues.deviceId).await()
            if (response.isSuccessful && response!=null) {
                ResponseResult.Success(response.body()!!)
            }else{
                ResponseResult.Error(response.message())
            }
        }catch (e:Exception){
            ResponseResult.Error("")
        }
    }
}
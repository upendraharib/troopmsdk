package com.tvisha.trooponprime.lib.clientModels

data class Contact(
    var mobile:String="",
    var name:String="",
    var country_code:String= "",
)
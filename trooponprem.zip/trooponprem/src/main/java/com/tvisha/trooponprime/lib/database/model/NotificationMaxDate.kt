package com.tvisha.trooponprime.lib.database.model

data class NotificationMaxDate(
    var created_at:String?= null,
    var muted:Int = 0
)

package com.tvisha.trooponprime.lib.apiResponse

import com.google.gson.annotations.SerializedName
import com.tvisha.trooponprime.lib.database.Permission


class PermissionsResponce {
    @SerializedName("success")
    var success: Boolean? = null
}